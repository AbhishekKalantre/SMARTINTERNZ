import React from "react";
import ProfilePage from "./Components/ProfilePage";

const App = () => {
  return (
    <div className="wrapper">
      <ProfilePage />
    </div>
  );
};

export default App;
